
package exemploheranca;
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Principal {

    public static void main(String[] args) {
        ArrayList<Pessoa> dado = new ArrayList<>();
        Pessoa novo;
        int op, op2;
        do{
            op = menuPrincipal();
            switch(op){
                case 1:
                    do{
                        op2 = menuInserir();
                        if(op2!=0){
                            novo = cadastro(op2);
                            dado.add(novo);
                        }    
                    }while(op2!=0);
                    
                break;
                case 2:
                    imprimir(dado);
                break;
                case 3:
                    calcQntdAlunos(dado);
                break;
                case 4:
                    calcPercFuncionario(dado);
                break;
                case 5:
                    calcMediaChProfessor(dado);
                break;
                case 6:
                    calcModa(dado);
                break;   
            }
        }while(op!=0);
    }
    private static int menuPrincipal(){
        int opcao;
        do{
        opcao = Integer.parseInt(JOptionPane.showInputDialog(
                "Menu de Opções\n"
                        + "0 - Sair\n"
                        + "1 - Inserir\n"
                        + "2 - Imprimir\n"
                        + "3 - Qtde de alunos\n"
                        + "4 - Percentual de Funcionários\n"
                        + "5 - Média da Ch dos Professores\n"
                        + "6 - Moda\n"));
            if(opcao<0 || opcao>6)
                JOptionPane.showMessageDialog(null, "Opção inválida!");
        }while(opcao<0 || opcao>6);
        return opcao;
    }

    private static int menuInserir() {
        int opcao;
        do{
        opcao = Integer.parseInt(JOptionPane.showInputDialog(
                "Escolha o objeto a ser inserido\n"
                        + "0 - Voltar ao menu Principal\n"
                        + "1 - Aluno\n"
                        + "2 - Funcionario\n"
                        + "3 - Professor\n"));
            if(opcao<0 || opcao>3)
                JOptionPane.showMessageDialog(null, "Opção inválida!");
        }while(opcao<0 || opcao>3);
        return opcao;
    }

    private static Pessoa cadastro(int op2) {
        Pessoa x;
        switch(op2){
            case 1:
                x = new Aluno();
                x.setNome(JOptionPane.showInputDialog("Digite o seu nome:"));
                x.setCpf(JOptionPane.showInputDialog("Digite o CPF:"));
                if(x instanceof Aluno){
                    ((Aluno)x).setMatricula(JOptionPane.showInputDialog("Digite a matricula:"));
                }
            break;
            case 2:
                x = new Funcionario();
                x.setNome(JOptionPane.showInputDialog("Digite o seu nome:"));
                x.setCpf(JOptionPane.showInputDialog("Digite o CPF:"));
                if(x instanceof Funcionario){
                    ((Funcionario)x).setCt(JOptionPane.showInputDialog("Digite o n° da Carteira de Trabalho:"));
                }
            break;
            default:
                x = new Professor();
                x.setNome(JOptionPane.showInputDialog("Digite o seu nome:"));
                x.setCpf(JOptionPane.showInputDialog("Digite o CPF:"));
                if(x instanceof Professor){
                    ((Professor)x).setCt(JOptionPane.showInputDialog("Digite sua Carga Horaria:"));
                    ((Professor)x).setCh(Integer.parseInt(JOptionPane.showInputDialog("Digite o n° da Carteira de Trabalho:")));
                }
            break; 
        }
        return x;
    }
    private static void imprimir(ArrayList<Pessoa> dado){
            if(dado.isEmpty())
                JOptionPane.showMessageDialog(null, "Lista Vazia!!!!");
            else{
                String texto="";
                for (Pessoa pessoa : dado) {
                    texto = texto + pessoa.toString()+ "\n";
                    
                }
                JOptionPane.showMessageDialog(null, texto);
                    
                
            }            
        }

    private static void calcQntdAlunos(ArrayList<Pessoa> dado) {
        int quant = 0;
        for (Pessoa pessoa : dado) {
            if(pessoa instanceof Aluno){
                quant++;
            }
            
        }
        JOptionPane.showMessageDialog(null, "A quantidade de alunos e: " +quant);
    }

    private static void calcPercFuncionario(ArrayList<Pessoa> dado) {
        int quant = 0;
        double perc;
        for (Pessoa pessoa : dado) {
            if(pessoa instanceof Funcionario){
                quant++;
            }
            
        }
        if(dado.isEmpty()){
            JOptionPane.showMessageDialog(null, "Lista Vazia!!");
        }
        else{
            perc = (double)quant/dado.size()*100;
            JOptionPane.showMessageDialog(null, "O percentual de funcionarios: " + perc + "%");
        }
    }

    private static void calcMediaChProfessor(ArrayList<Pessoa> dado) {
        int quant = 0;
        int soma = 0;
        double media;
        for (Pessoa pessoa : dado) {
            if(pessoa instanceof Professor){
                quant++;
                soma = soma + ((Professor)pessoa).getCh();
            }
        }
        if(quant == 0){
            JOptionPane.showMessageDialog(null, "Não há professores cadastrados!!");
        }
        else{
            media = (double)soma/quant;
            JOptionPane.showMessageDialog(null, "A media de carga horária dos professores e: " + media);
        }
    }

    private static void calcModa(ArrayList<Pessoa> dado) {
        String[] tipo = {"Aluno", "Funcionario", "Professor"};
        int [] quant = {0, 0, 0};
        for (Pessoa pessoa : dado) {
            if(pessoa instanceof Aluno)
                quant[0]++;
            if(pessoa instanceof Funcionario)
                quant[1]++;
            if(pessoa instanceof Professor)
                quant[2]++;
        }
        //Calculo da frequencia de cada objeto//    
        String texto="";
        for (int i = 0; i < tipo.length; i++) {
            texto = texto + tipo[i] + " - " + quant[i] + "\n";
        }
        JOptionPane.showMessageDialog(null, "A frequencia de cada objeto:\n" +texto);
        
        int auxQuant;
        String auxTipo;
        for (int i = 0; i < quant.length-1; i++) {
            for (int j = 0; j < quant.length; j++) {
                if(quant[i]>quant[j]){
                    auxQuant = quant[i];
                    quant[i] = quant[j];
                    quant[j] = quant[i];
                    auxTipo = tipo[i];
                    tipo[i] = tipo[j];
                    tipo[j] = auxTipo;
                }
            }
            
        }
        JOptionPane.showMessageDialog(null, "A moda e: \n" + tipo[tipo.length-1] + "com " +quant[quant.length-1] + "ocorrencias");
    }
    
    
}
